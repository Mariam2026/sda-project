package com.example.demo.models;

public enum RoomType {
    SINGLE,
    DOUBLE,
    FAMILY
}
