package com.example.demo.services;



public interface NotificationObserver {
    void update(String message); // Method for observers to receive notifications
}
