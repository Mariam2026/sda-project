public class ooo {
}
